=== WC-Persian ===
Contributors: salemi
Donate link: https://zarinp.al/22741
Tags: persian, farsi, jalali, date, calendar, iran, woocommerce, shamsi, فارسی, تقویم, شمسی, هجری شمسی, افزونه, جلالی, میلادی, پارسی, ایران, ووکامرس, فروشگاه
Requires at least: 4.0
Tested up to: 4.9.6
Stable tag: 1.0.1
License: GPL2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Fast and powerful plugin based on WP-Persian for support jalali date in Woocommerce.

== Description ==

WC-Persian is a fast and powerful plugin based on WP-Persian for support jalali date in Woocommerce.

> If you like the plugin, feel free to rate it (on the right side of this page)!

Related Links:

* <a href="http://www.30yavash.com/tag/wp-persian/" title="Farsi Online Documents">Online Documents</a>
* <a href="https://plugins.svn.wordpress.org/wp-persian/assets/help.pdf" title="Farsi Help">PDF Document</a>
* <a href="https://plugins.svn.wordpress.org/wp-persian/assets/install.pdf" title="Farsi Installation Help">PDF Installation Help</a>
* <a href="https://youtu.be/4BIaH5_y-u8" title="Video Demo on Youtube">Video Demo</a>


= Farsi Description =
* پشتیبانی از تاریخ هجری شمسی در پلاگین ووکامرس


= Features =
* Jalali DatePicker for Woocommerce

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/wc-persian` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Use the Settings->Persian screen to configure the plugin

== Changelog ==
= 1.0.0 (June 21th,2018)=
* (NEW) first release

== Frequently asked questions ==

= I found a bug in the plugin. =
Please post it in the [Plugin Homepage](http://www.30yavash.com/tag/wp-persian/) and we'll fix it right away. Thanks for helping.

= Does WP-Persian Support Multisite? =
yes.

= Which version of Wordpress should I use? =
use can use English or Persian version of Wordpress.but we suggest english version.
